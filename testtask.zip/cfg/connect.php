<?php
	///database connection settings

	define('DB_HOST', 'localhost'); // database host
	define('DB_USER', 'root'); // username
	define('DB_PASS', ''); // password
	define('DB_NAME', 'testtask'); // database name
	define('ADMIN_LOGIN', 'admin'); //administrator's login
	define('ADMIN_PASS', ''); //administrator's password

?>